const mongoose = require('mongoose')

const Schema= mongoose.Schema;

const movieSchema = new Schema({
    year : Number,
    title : String,
    info : {
        directors: Array,
        release_date : Date,
        rating : Number,
        genres : Array,
        image_url : String,
        plot : String,
        rank : Number,
        running_time_secs : Number,
        actors : Array
    }
})

module.exports = mongoose.model('movieSchema',movieSchema)