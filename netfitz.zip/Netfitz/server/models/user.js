const express = require('express')
const mongoose = require('mongoose');
const { stringify } = require('querystring');
const bcrypt = require('bcrypt')

const Schema = mongoose.Schema;

const User = new Schema({
    firstname : String,
    lastname : String,
    email : String,
    password : String,
    salt : String,
    hash: String

})

User.pre('save', async function(next) {
    let { password } = this;
    this.salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(password, this.salt);
});

module.exports = mongoose.model('user',User)