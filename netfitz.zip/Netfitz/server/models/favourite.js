const express = require('express')
const mongoose = require('mongoose')
const user = require('./user')


const Schema = mongoose.Schema

const favouriteSchema = new Schema ({
    userid : String,
    userplusmovieid : {type:String, unique:true},
    year : Number,
    title : String,
    info : {
        directors: Array,
        release_date : Date,
        rating : Number,
        genres : Array,
        image_url : String,
        plot : String,
        rank : Number,
        running_time_secs : Number,
        actors : Array
    }
})

favouriteSchema.pre("save", async function(next){
    this.userplusmovieid = this.userid + this._id
})

module.exports = mongoose.model('favschema',favouriteSchema)