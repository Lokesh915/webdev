const express = require('express')
const User = require ('../models/user')
const cors = require('cors')
const route = express.Router()
const bcrypt = require('bcrypt')
const nodemailer = require('nodemailer')
route.use(cors())





route.post('/', async (req, res) => {
    
 
    try {
        let exist = await User.findOne({ email: req.body.email })
        if (exist) {
            return res.status(400).json({message:'Try another Username',  bool : false})
        }
       
        await User.create(req.body)
       
    //    NodeMailer code
        var transporter = nodemailer.createTransport({
            service:'Outlook365',
            auth:{
                user : 'lokesh.ravipati@outlook.com',
                pass:'lokesh@143'
            }
        });
    // Mailing options
        var mailoptions = {
            from : 'lokesh.ravipati@outlook.com',
            to : req.body.email,
            subject : 'registeration',
            text : 'successfully registered to movies application'
        };
    // sending Mail
        transporter.sendMail(mailoptions, function(err,info){
            if(err){
                console.log(err)
            } else {
                console.log('email sent ' + info.response)
            }
        })
          
        res.status(200).json({message:'Registered Successfully', bool : true})
    } catch (err) {
        console.log(err)
        return res.send('server Error'+ err)
    }
})
module.exports = route
