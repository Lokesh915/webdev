const express = require('express')
const route= express.Router()
const Movie = require('../models/movieSchema')
const cors = require('cors')

route.use(cors())
route.get('/', async (req, res) => {
	let genres = await Movie.distinct('info.genres')
	let movieArray = []
	for (const genre of genres){
		let movies = await Movie.aggregate([
			{ $match : { 'info.genres' : genre } },
			{
			  $sort: {
				'info.rating' :-1,
			  }
			},
			{
			  $limit: 10
			}
			
		  ])
	movieArray.push({
		title:genre,
		movies : movies
	})
	}
	
	  res.json(movieArray)
})

module.exports = route