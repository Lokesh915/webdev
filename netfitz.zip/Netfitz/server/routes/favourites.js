const express = require('express')
const route = express.Router()
const favourites = require('../models/favourite')
const middleware = require('./middleware')
const cors = require('cors')
route.use(cors())


route.post('/', async(req,res)=>{
   await favourites.create(req.body)
   res.status(200).json({
       message:'added to favourites'
   })
})

route.get('/',async (req,res)=>{
    let result=await favourites.find({userid : req.body.userid})
    if(result){
        res.status(200).json({resutl:result})
    }

})

module.exports=route

   

