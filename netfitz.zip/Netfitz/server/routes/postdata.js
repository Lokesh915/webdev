const express = require('express')
const cors = require('cors')
const fs = require('fs')
const route = express.Router()

const Movie = require('../models/movieSchema')
route.use(cors())

route.post('/', async (req, res) => {
    try {
        console.log(__dirname)
        let data =  fs.readFileSync(__dirname+'/movies.json', 'utf8')
       
    
        let parsedata = JSON.parse(data)
        console.log('Post'+ parsedata.length);
        let result= await Movie.insertMany(parsedata)
        
        res.send(result.length)
    }catch(err){
        res.send(err)
    }

})

module.exports = route
