const express = require('express')
const route = express.Router()
const user = require('../models/user')

const cors= require('cors')
const { application } = require('express')
route.use(cors())

route.delete('/', async (req,res)=>{
    console.log(req.body)
    await user.deleteOne(req.body.email)

    res.status(200).json({
        message: 'Account Deleted successfully'
    })
})

module.exports= route