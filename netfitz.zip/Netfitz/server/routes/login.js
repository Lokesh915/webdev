const express = require('express')
const route = express.Router()
const cors = require('cors')
const User = require('../models/user')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
route.use(cors())

route.use(express.json())

route.post('/', async (req,res)=>{
    console.log(req.body.email);
    let user = await User.findOne({email : req.body.email})
    if(!user){
        res.json('Username/password is incorrect')
    }
    console.log(req.body.password);
    let validatepassword= await bcrypt.compare(req.body.password, user.password)
    
    let payload = {
        person :{
            id : user.id
        }
    }
    if(validatepassword){
        jwt.sign(payload,'jwtSecret',
            (err,token)=>{
                if(err) throw err;
                console.log(token);
               res.status(200).json({ 
                token : token,
                message : 'loggedin successfully',
                user : user
             })
                 
            })
    }
    else{
        res.status(500).send('Username/password is incorrect')
    }

})

module.exports = route