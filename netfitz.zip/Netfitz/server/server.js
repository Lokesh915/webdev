const express = require('express');
const postdata = require('./routes/postdata')
const register = require('./routes/register')
const login = require('./routes/login')
const jwt = require('jsonwebtoken')
const favourites = require('./routes/favourites')
const genre = require('./routes/genre')
const Movie = require('./models/movieSchema')
const deleteuser = require('./routes/delete')

const mongoose = require('mongoose')


const app = express()
app.use(express.json())

mongoose.connect('mongodb+srv://lokesh143:lokesh143@cluster0.3e0dm.mongodb.net/myFirstDatabase?retryWrites=true&w=majority').then(()=>{
   console.log( 'DB connected')
})

app.get('/', (req,res)=>{
    console.log('getting')
    res.send(200)
})
app.use('/postdata',postdata)
app.use('/register', register)
app.use('/login', login)
app.use('/favourites', favourites)
app.use('/genre',genre)
app.use('/delete', deleteuser)

app.listen(3001, (req,res)=>{
    console.log('server listening')
})