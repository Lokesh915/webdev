import React, {useContext} from 'react'
import { store } from '../App'
import Cardstructure from './cardstructure'
import Viewcard from './viewcard'
export default function Favourites({liked}) {
    const [ user,setUser] = useContext(store)

  return (
    <div>
        
        {liked.resutl.map(likes=><Viewcard movie={likes}/>)}
        

    </div>
  )
}
