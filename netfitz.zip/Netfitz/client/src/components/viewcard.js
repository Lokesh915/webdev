import React, {useState} from 'react'
import { FaCalendarAlt } from "react-icons/fa";
import { IoIosPeople } from "react-icons/io";
import { BiMoviePlay } from "react-icons/bi";
import { IconContext } from "react-icons";


export default function Viewcard({movie}) {
    const [imgURL, setImgURL]= useState(movie.info.image_url);

    const hanldeError=()=>{
        setImgURL('https://media.gettyimages.com/vectors/cinema-poster-with-cola-filmstrip-and-clapper-vector-vector-id1244034031?s=2048x2048');
    }

    let changedate = (value)=>{
        let date = new Date(value);
        let year = date.getFullYear();
        let month = date.getMonth()+1;
        let dt = date.getDate();

        if (dt < 10) {
        dt = '0' + dt;
        }
        if (month < 10) {
        month = '0' + month;
        }

        return (month+'-' + dt + '-'+year);
            }
    
  return (
    <div className='detail'>
        <img className='viewimage' src= {imgURL} onError={hanldeError} />
        <IconContext.Provider value={{ className: "shared-class", size: 30 }}>
        <h3> {<FaCalendarAlt/>} {changedate(movie.info.release_date)} </h3>
        <h4> <strong>{<IoIosPeople/>} {movie.info.actors.map(actor => actor + ', ' )}</strong></h4>
        <p><strong>{<BiMoviePlay/>}{movie.info.plot}</strong> </p>
        </IconContext.Provider>

    </div>
  )
}
