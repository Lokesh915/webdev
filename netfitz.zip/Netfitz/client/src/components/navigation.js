import React, {useContext,useState} from 'react'
import { Link } from 'react-router-dom'
import Settings from './settings'
import {store} from '../App'
import '../App.css'
import { BiLogIn } from "react-icons/bi";
import { SiGnuprivacyguard } from "react-icons/si";
import { FcLike,FcRating } from "react-icons/fc";
export default function Navigation() {
  const [user,setUser] = useContext(store)

  return (
    <div className='nav'>
      <h1>NETFITZ</h1>
      <div className='group'>
        
          {user?'':<button> <Link to='/register'> {<SiGnuprivacyguard/>} Register</Link> </button>}
          {user?<button><Link to='settings'>settings</Link></button>:<button> <Link to='/login'> {<BiLogIn/>} Login</Link> </button>}
          <button><Link to='favourites'>{<FcLike/> }Favourites</Link></button>
      </div>
    </div>
  )
}
