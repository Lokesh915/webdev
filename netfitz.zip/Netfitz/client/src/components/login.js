import axios from 'axios';
import React, {useState,useContext} from 'react'
import {store} from '../App'
import { useNavigate } from 'react-router-dom'
import Cookies from 'universal-cookie';

const cookies = new Cookies()
export default function Login() {
    const[user,setUser]=useContext(store)
    const[logindata, setLogindata] = useState({
        email : '',
        password : ''
    })
    const Navigate = useNavigate();
  

    const handlelogin =(e)=>{
        setLogindata({...logindata,[e.target.name]:[e.target.value]})
    }
    const submitlogin = (e)=>{
        let payload={
            email: logindata.email[0],
            password: logindata.password[0]
        }
        e.preventDefault();
        axios.post('http://localhost:3001/login',payload).then((response)=>{
        alert(response.data.message)
        setUser(response.data.user)
        // cookie is getting created 
        cookies.set('userdata',JSON.stringify(response.data.user))
        if(response.data.user){
            Navigate('/')
        }
        
    })
    }



  return (
    <div className='loginform'>

        <form onSubmit={submitlogin}>
            <h4>
                Login
            </h4>
            <div>
                <label>Email</label>
                <input type='email' name='email'  onChange ={handlelogin}/>
            </div>
            <div>
                <label>password</label>
                <input type='password' name='password'  onChange ={handlelogin}/>
            </div>
            <button>Login</button>
        </form>
    </div>
  )
}
