import axios from 'axios'
import React from 'react'
import { useContext,useState } from 'react'
import {store} from '../App'
import { useNavigate } from 'react-router-dom'
import Cookies from 'universal-cookie'
const cookies = new Cookies()
export default function Settings() {
    const [user,setUser]= useContext(store)
    const Navigate = useNavigate(); 
    const handledelete = ()=>{
        console.log(user)
        axios.delete('http://localhost:3001/delete', user).then((res)=>{
            alert(res.data.message)
            console.log(res)
            Navigate('/register')

        } )
    }
    const handlelogout=()=>{
    // cookie is getting reomved on click
        setUser(cookies.remove('userdata'))
        Navigate('/login')
    }
  return (
    <div className='settings'>
        <h3>PROFILE</h3>
        <button onClick={handledelete}>Delete Account</button>
        <button onClick={handlelogout}>Logout</button>
    </div>
  )
}
