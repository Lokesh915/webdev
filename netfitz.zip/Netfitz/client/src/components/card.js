import React from 'react'
import '../App.css'
import Cardstructure from './cardstructure'

export default function card({ movies, viewMovie, viewfavourite  }) {

    return (


        <div className='cards'>
            
            {movies.map(item => (
            <div >
                <h3>{item.title}</h3>
                <div className='movierow'>
                {item.movies.map(item=>(
                
                <Cardstructure key={item._id} movie={item} viewMovie={viewMovie} viewfavourite={viewfavourite}/>
                ))}
            </div>
            </div>    
            ))}
        </div>
    )
}
