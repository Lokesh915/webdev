import React, {useState, useContext} from 'react'
import { Link } from 'react-router-dom';
import { store } from '../App';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { BsEyeFill } from "react-icons/bs";
import { FcLike,FcRating } from "react-icons/fc";
import { BiTimeFive } from "react-icons/bi";

export default function ({movie, viewMovie, viewfavourite}) {
    const [imgURL, setImgURL]= useState(movie.info.image_url);
    const [user,setUser] = useContext(store)
    const [favourited,setFavourited] = useState([])
    const Navigate = useNavigate()
    const hanldeError=()=>{
        setImgURL('https://media.gettyimages.com/vectors/cinema-poster-with-cola-filmstrip-and-clapper-vector-vector-id1244034031?s=2048x2048');
    }
    const durationFormat = (sec) => {
		let sec_num = parseInt(sec, 10);
	    let hours   = Math.floor(sec_num / 3600);
	    let minutes = Math.floor((sec_num - (hours * 3600)) / 60);

	    return `${hours}h ${minutes}m`
	}
    const view = (data)=>{
        viewMovie(data)
    }
    const handlefavourite = (data)=>{
        if(user){
            
            
            axios.post('http://localhost:3001/favourites',data).then(res=> alert(res.data.message))
            let favs = axios.get('http://localhost:3001/favourite')
            setFavourited(favs)
            viewfavourite(favourited)
            
        }else{
            Navigate('/login')
        }
    }
  return (
        
            <div className="card" >
                <img className='img' width='200px' height='250px' src={imgURL} onError={hanldeError}/>
                
                <div className='button'>
                    <strong >{movie.title}</strong>
                    <div >{<FcRating/>} : {movie.info.rating}</div>
                    <div >{<BiTimeFive/>}: {durationFormat(movie.info.running_time_secs)}</div>
                    <button onClick={(e)=>view(movie)}> <Link to='viewcard'>{<BsEyeFill/>}View more</Link> </button>
                    <button onClick={(e)=>handlefavourite(movie)}>{<FcLike/>}Add to favorites</button>
                </div>
            </div>
        
        
    
  )
}
