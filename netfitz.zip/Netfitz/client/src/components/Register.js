import axios from 'axios'
import React, {useState} from 'react'
import { useNavigate } from 'react-router-dom'

export default function () {
  
    const [data, setData] = useState({
        firstname :'',
        lastname :'',
        email:'',
        password:''
    })
    const Navigate = useNavigate();

    const submitregister = (e)=>{
            e.preventDefault();
            axios.post('http://localhost:3001/register',data).then((response)=>{
            alert(response.data.message)
            if(response.data.bool){
                Navigate('/')
            }
        })
        
    }

    const handleregister=(e)=>{
        setData({...data,[e.target.name]:e.target.value})
    }

   
  return (
    <div className='form'>
        <form onSubmit={submitregister}>
            <h3>Register</h3>
            <div>
                <div>
                    <label>First Name</label>
                    <input type='text' name='firstname'  onChange ={handleregister} />
                </div>
                <div>
                    <label>Last Name</label>
                    <input type='text' name='lastname'  onChange ={handleregister} />
                </div>
                <div>
                    <label>Email</label>
                    <input type='email' name='email'  onChange ={handleregister}/>
                </div>
                <div>
                    <label>password</label>
                    <input type='password' name='password'  onChange ={handleregister} />
                </div>
                <button >Submit</button>

            </div>
        </form>
    </div>
  )
}
