import React, {useEffect,useState,createContext,useContext} from "react";
import Navigation from './components/navigation'
import Card from './components/card'
import Login from './components/login'
import CookieConsent from "react-cookie-consent"; 
import Viewcard from "./components/viewcard";
import Settings from './components/settings'
import axios from 'axios';
import Favourites  from "./components/favourites";
import { BrowserRouter, Routes, Route, Link, useNavigate } from "react-router-dom";
import Register from "./components/Register";
import Cardstructure from "./components/cardstructure";
import Cookies from "universal-cookie"
export const store = createContext();

// cookie initialization
const cookies = new Cookies()

function App() {

  useEffect(()=>{
    setUser(cookies.get('userdata'))
    console.log(user)
    axios.get('http://localhost:3001/favourites').then(res=>{
      console.log(res.data)
      setFavourite(res.data)
    })
  },[])
  const [movies,setMovies] = useState([])
  const [movie, setMovie] = useState('')
  const [user,setUser] = useState(null)
  const [favourite,setFavourite] = useState({})
  useEffect(()=>{
      axios.get('http://localhost:3001/genre').then((response)=>{
      setMovies(response.data)
      // console.log(movies)
    }).catch(err=>{
      console.error(err);
    });
    
  },[])
  const viewMovie=(data)=>{
   setMovie(data);
  }
  const viewfavourite = (data)=>{
    setFavourite(data)
  }

  return (
    <div className="body">
      <store.Provider value={[user,setUser]}>
      <BrowserRouter>
        <Navigation/>
      
        <Routes>
          <Route path ='/' element={<Card movies={movies} viewMovie={viewMovie} viewfavourite={viewfavourite}/>} />
          <Route path='/register' element={<Register/>} />
          <Route path='/login' element={<Login/>} />
          <Route path='/viewcard' element={<Viewcard movie={movie}/>} />
          <Route path='/settings' element={<Settings />} />
          <Route path='/favourites' element={<Favourites liked={favourite}/> } />

        </Routes>
      </BrowserRouter>
      
      <CookieConsent debug={true}>This site uses cookies.</CookieConsent>
      </store.Provider>
      
    </div>
  );
}

export default App;
