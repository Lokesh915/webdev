const express= require('express')
const bodyparser = require('body-parser')
const Recipes = require("./model")
const route = express.Router()
const fs= require('fs')
 cors = require('cors')

route.use(cors())
route.use(bodyparser.json())
route.post('/', async (req,res)=>{
    console.log(req.body,"req")
    const name = req.body.name;
    const description = req.body.description 
    const ingredients = req.body.ingredients

    await Recipes.create({name:name,description: description,ingredients:ingredients})
    return res.sendStatus(200)
})

module.exports= route;