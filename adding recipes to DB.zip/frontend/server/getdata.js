const express= require('express')
const Recipes = require("./model")
const route = express.Router()

let cors = require('cors')

route.use(cors())

route.get('/', async (req,res)=>{
    try{
    let data= await Recipes.find()
    res.send(data)
    }
    
    catch{
        res.send(error)
    }
})

module.exports= route;