const express = require('express');
const mongoose = require('mongoose')
const recipetodb= require('./recipetodb')
const addrecipe = require ('./addrecipe')

const getdata = require('./getdata')
const App = express();



App.use('/api/recipetodb', recipetodb)
App.use('/api/addrecipe', addrecipe)
App.use('/api/getdata', getdata)



App.get('/', (req,res)=>{
    res.send('running....')
});

mongoose.connect('mongodb+srv://lokesh143:lokesh143@cluster0.3e0dm.mongodb.net/myFirstDatabase?retryWrites=true&w=majority')



App.listen(3001);