const express= require('express')
const Recipes = require("./model")
const route = express.Router()
const fs= require('fs')
var cors = require('cors')

route.use(cors())
route.post('/', async(req,res)=>{
    try{
        let data = fs.readFileSync('./recipes.json');
        let parsedata = JSON.parse(data)
        for (i=0; i<782; i++){
            await Recipes.create(parsedata[i]) 
        }
        res.send('entered')
    }
    catch(err) {
        res.json(err)
    }
})

module.exports = route