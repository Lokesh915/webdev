const mongoose = require("mongoose")

const userschema = new mongoose.Schema({
    name: String,
    description : String,
    image : String,
    recipeYeild: String,
    cookTime: String,
    prepTime: String,
    ingredients : Array
});

// const formschema = new mongoose.Schema({
//     name : String,
//     desciption : String,
//     ingredients : Array
// })

module.exports= mongoose.model('model', userschema)
// module.exports = mongoose.model('formmodel', formschema)