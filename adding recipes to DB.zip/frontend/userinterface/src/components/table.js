import React from 'react'

export default function Table({newIngredients}) {
  return (
    <div className="d-flex justify-content-center" >
        <table className="table">
            <thead>
                <tr>
                    <th>Quantity</th>
                    <th>Ingredient</th>
                </tr>
            </thead>
            <tbody>
                {newIngredients.map((ele,index)=>(
                    <tr key={index}>
                        <td>{ele.quantity}</td>
                        <td>{ele.ingredient}</td>
                    </tr>
                ))}
            </tbody>

        </table> 
    </div>
  )
}
