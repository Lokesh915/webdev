import React from 'react'
import { useState, useEffect } from 'react'
import axios from 'axios';
import Table from './table';

export default function Form() {
 
	const [newIngredients, setNewIngredients] = useState([]);
	const [ing, setIng] = useState('');
	const [qty, setQty] = useState('');
	const [description, setDescription] = useState('');
	const [name, setName] = useState('');
	const [count,setCount] = useState(0)
    // const [populateBtn, setPopulateBtn] = useState(false);
	const [ingredients, setIngredients] = useState([]);

	// Fetching data from database
    useEffect(() => {
		const fetchAllRecipes = async () => {
				const res = await axios.get('http://localhost:3001/api/getdata');
				setCount(res.data.length)
				
				let array = [];

				for (const recipe of res.data) {
					array.push(...recipe.ingredients)
				};

				let newArray = []

				for (let data of array) {
					data = data.replace(/ *\([^)]*\) */g, "");
					data = data.replace(/[0-9]/g, '');
					data = data.replace(/[^a-zA-Z ]/g, "");
					data = data.replace('cup', '');
					data = data.replace('cups', '');
					data = data.replace('ounces', '');
					data = data.replace('teaspoon', '');
					data = data.replace('teaspoons', '');
					data = data.replace('tablespoon', '');
					data = data.replace('tablespoons', '');
					data = data.replace('tbsp', '');
					data = data.replace('tsp', '');
					data = data.replace('goz', '');
					data = data.replace('glb', '');
					data = data.replace('mlfl', '');
					data = data.replace('oz', '');
					data = data.trim();
					data = data.split(' ')[0] === 's' ? data.replace('s', '') : data;
					data = data.trim();
					data = data.split(' ')[0] === 'g' ? data.replace('g', '') : data;
					data = data.trim();
					data = data.split(' ')[0] === 'fl' ? data.replace('fl', '') : data;
					data = data.trim();
					data = data.split(' ')[0] === 'ml' ? data.replace('ml', '') : data;
					newArray.push(data.trim());
				};

				let uniqueChars = [...new Set(newArray)];

				setIngredients(uniqueChars);

			
		}
		fetchAllRecipes();
	}, [])
	
//    funtion for Saving recipe on click
    const handleSaveRecipe = async (e) => {
		e.preventDefault();
		if (newIngredients.length === 0) {
			
			return false;
		} else {
			let arr = [];

			for (const ind of newIngredients) {
				console.log(ind,"ind")
				arr.push(`${ind.quantity}, ${ind.ingredient}`)
				console.log(arr,"array")
			};

			const data = {
				description,
				name,
				ingredients: arr,
			};
			try {
				console.log(data)
				await axios.post('http://localhost:3001/api/addrecipe', data);
				
				
				
			} catch (err) {
				console.log(err.response?.data);
			}

			setDescription('');
			setName('');
			setNewIngredients([]);
		}
	};

//  function for adding ingredient to add on top of form
    const handleAddIngredient = () => {
        const data = {
            quantity: qty,
            ingredient: ing,
        };

        if (qty && ing) {
            setNewIngredients((preval) => {
                return [...preval, data]
            })
        };
        setQty('');
        setIng('');
    };


  return (
    <div className='container'>
        <form onSubmit={handleSaveRecipe} className="form-group">
			<h5>Total recipe count : {count}</h5>
            <h2 className="text-uppercase">Add Recipe</h2>
            <br/>
            <div>
                <label className='text-uppercase'>Name </label>
                <input className="form-control" type= 'text' value={name} onChange={(e) => setName(e.target.value)}/>
            </div>
            <div>
                <label className='text-uppercase'>description </label>
                <textarea className="form-control" value={description} onChange={(e) => setDescription(e.target.value)} ></textarea>
            </div>
        
            <br></br>

            {newIngredients?.length > 0 ? <Table  newIngredients={newIngredients} /> : ''}
            
            <h4>Add Ingredient</h4>
        
                
            <br></br>
            <div>
                <label className='text-uppercase'>Quantity </label>
                <input className="form-control" value={qty} onChange={(e) => setQty(e.target.value)} type="text"  />
            </div>
            <div>
                <label className='text-uppercase'>Ingredient </label>
                <div >
                    <input className="form-control" value={ing} onChange={(e) => setIng(e.target.value)}  list="datalistOptions" />
                    <datalist id="datalistOptions">
                        {ingredients.map((item) => <option key={item} value={item} />)}
                    </datalist>
                </div>
                
            </div>
            <br></br>
            <button onClick={handleAddIngredient} type='button' >Add Ingredient</button>
			{console.log(newIngredients)}
            <br></br>
            <button type="submit" onClick={handleSaveRecipe} >Save Recipe</button>
			
			
        </form>

    </div>
  )
}
