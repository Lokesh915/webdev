import React, {useState} from 'react'
import axios from "axios";
import {Link} from "react-router-dom";
import Loader from './spinner'; 

export default function Navigation() {

  // initializing flags
  const [btn, setBtn] = useState(true);
  const [spinner, setSpinner] = useState(false)
    const handleclick = async ()=>{
      setSpinner(true)

      //  posting data to DB
      await axios.post('http://localhost:3001/api/recipetodb')
      setBtn(false)
      setSpinner(false)
    }
    
  return (
    <div className="btn btn-success float-right">
          {spinner ? <Loader/> : ''}
          <div >
            {btn ? <button  onClick={handleclick}>Publish Data</button> :"Data published successfully"}
              <button > <Link to='./form'>Add Recipe</Link></button>
          </div>
    </div>
  )
}
