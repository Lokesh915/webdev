import React from 'react';
import '../App.css';

// creating Spinner
const Loader = () => {
    return (
        <div className="spinner-container">
            <div className="loading-spinner">
                
            </div>
            <p>Publishing data....</p>
        </div>
    )
};

export default Loader;
