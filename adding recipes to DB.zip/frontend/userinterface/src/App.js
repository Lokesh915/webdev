
import './App.css';
import Form from './components/form' 
import Navigation from './components/navigation'
import {BrowserRouter, Routes, Route} from 'react-router-dom';
function App() {
  return (
    <div className="App">
      
      <BrowserRouter>
        <Navigation/>
        <Routes>
          <Route path="/form" element={<Form/>}/>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
