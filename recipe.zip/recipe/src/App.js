import { useState } from 'react';
import Navigation from './components/navigation';
import Search from './components/search';
import Card from './components/card';
import SingleRecipe from './components/singlecard';
import Grocery from './components/grocery'
import Favourite from './components/favourite'
import { BrowserRouter, Routes, Route, Link, useNavigate } from "react-router-dom";
import './App.css'
import UserContext from './components/User';


export default function App() { 
  
  const [data, setData] = useState([]);
  const [recipes, setRecipes ] = useState({})
  const [ingridients, setIngridients ] = useState([])
  const [favourites, setFavourites] = useState([])
  // A function for filtering with name 
  let filterbyname = function(events, filtervalue){
    if(!filtervalue){
      return []
    }
    let names = events.filter((event)=>{
        if(event.name.toLowerCase().includes(filtervalue.toLowerCase()) || 
          event.description.toLowerCase().includes(filtervalue.toLowerCase()) ||
          event.ingredients.toString().toLowerCase().includes(filtervalue.toLowerCase())){
          return event
        }  
    })
    return names
}
 
  // fetching data from json file 
  const search = (word) =>{
    fetch("recipes.json")
      .then(response => response.json())
      .then((result) => result)
      .then(jsondata => filterbyname(jsondata, word))
      .then(jsondata => {
          setData(jsondata)
          console.log(data)
        })
  }
 
  const ViewRecipe = (data) => {
    setRecipes(data)  
  }

  const viewFavourite = (favourite) => {
    setFavourites([...favourites, favourite])
  }
  
  const removeFavourite = (favourite) =>{
    const data = [...favourites]
    const favouriteIndex = data.findIndex((theFavourite=> theFavourite === favourite))
    if(favouriteIndex < 0){
      return;
    }
    data.splice(favouriteIndex,1)
    setFavourites(data)
  }

  const addIngridient = (ingridient) => {
    setIngridients([...ingridients, ingridient])
  }

  const removeIngridient = (ingridient) => {
    const data = [...ingridients]
    const ingridientIndex = data.findIndex((Ingridient => Ingridient === ingridient))
    if(ingridientIndex < 0){
      return;
    }
    data.splice(ingridientIndex, 1)
    setIngridients(data)
  
  }
  
  const user = "lokesh"
  return (
    <div>
      <UserContext.Provider value={user}></UserContext.Provider>
      <Navigation name={user} ingridients={ingridients} favourites={favourites}
      removeFavourite={removeFavourite} removeIngridient={removeIngridient}/>
      <img className='img' src='recipefinder.png' alt='recipefinder'/>
      <Search search={search}/>

      <BrowserRouter>
        <Routes>
          <Route path='/' element={ <Card data={data} ViewRecipe={ViewRecipe} ViewFavourite={viewFavourite}/>} />
          <Route path='singlecard' element={<SingleRecipe recipes={recipes} addIngridient={addIngridient}/> } />
          <Route path='grocery' element={<Grocery ingridients={ingridients} removeIngridient={removeIngridient} />} />
          <Route path='favourite' element={<Favourite favourites={favourites} removeFavourite={removeFavourite} />} />
        </Routes>
      </BrowserRouter>

    </div>
  )

}


