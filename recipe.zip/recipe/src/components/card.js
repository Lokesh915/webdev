import React from 'react'
import {parse} from 'iso8601-duration'
import {  Link } from "react-router-dom";

export default function card({data,ViewRecipe, ViewFavourite}) {


    const timechanging = (duration) => {
		const output = parse(duration);
		return `${output.hours}:${output.minutes}`;
	}
    
    const View = (item)=>{
        ViewRecipe(item)

    }
	const Favourite=(item)=>{
		ViewFavourite(item)
	}
    
  return (
    <div className='cards'>
        {data.map(item => (
			<div  className="card">
					<img src={item.image} alt={item.name} />
					<h5>{item.name}</h5>
					<p><strong>CookTime:</strong> {item.cookTime ? timechanging(item.cookTime): 'N/A'}</p>
					<p><strong>PrepTime:</strong> {item.prepTime ? timechanging(item.prepTime): 'N/A'}</p>
					<p><strong>Yield:</strong> {item.recipeYield ? item.recipeYield: 'N/A'}</p>
					<button className="button1" onClick={(e)=>View(item)} data-recipe={item}><Link className='button1' to='singlecard'> View </Link></button>
					<button className="button" onClick={(e)=>Favourite(item.name)}>Add Favourite</button>
			</div>))
		}
    </div>
  )
}
