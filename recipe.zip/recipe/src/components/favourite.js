import React from 'react'

export default function favourite({favourites,removeFavourite}) {
  return (
    <div className='Favourite'>
        
    <ul>
      {favourites.map(favourite => (
          <li key={favourite}>
            {favourite}
            <button onClick={(e) => removeFavourite(favourite)} >-</button>
          </li>
        )
      )}
    </ul>
    </div>
  )
}
