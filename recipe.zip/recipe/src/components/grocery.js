import React from 'react'

export default function grocery({ingridients,removeIngridient}) {
  return (
    <div className="Grocery">
    
    <ul>
      {ingridients.map(ingridient => (
          <li key={ingridient}>
            {ingridient}
            <button onClick={(e) => removeIngridient(ingridient)} >-</button>
          </li>
        )
      )}
    </ul>
  </div>
  )
}





