import React from 'react'
import {parse} from 'iso8601-duration'

export default function singlecard({recipes,addIngridient}) {

    const timechanging = (duration) => {
		const output = parse(duration);
		return `${output.hours}:${output.minutes}`;
	}

  return (
    <div className="Recipe">
  
      <img src={recipes.image} alt={recipes.name} />
      <h3>{recipes.name}</h3>
      <p><strong>CookTime:</strong> {recipes.cookTime ? timechanging(recipes.cookTime): 'N/A'}</p>
      <p><strong>PrepTime:</strong> {recipes.prepTime ? timechanging(recipes.prepTime): 'N/A'}</p>
      <p><strong>Yield:</strong> {recipes.recipeYield ? recipes.recipeYield: 'N/A'}</p>
      <p>{recipes.description}</p>
      <hr />
      <h3>Ingridients</h3>
      <ul>
        {recipes.ingredients.map(ingridient => (
            <li key={ingridient}>
              {ingridient}
              <button onClick={(e)=>addIngridient(ingridient)}>+</button>
            </li>
          )
        )}
      </ul>
    </div>
  )
}
