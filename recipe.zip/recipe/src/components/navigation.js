import React from 'react'
import { useState } from 'react';
import Grocery from './grocery';
import Favourite from './favourite';

export default function ({ name, ingridients, removeIngridient, favourites,removeFavourite}) {
  const [show, setShow] = useState(false)
  const [click, setClick] = useState(false)
  return (
    <div className="Navigation">
      <button onClick={(e) => setClick(!click)}>Favourites ({favourites.length})</button>
      { click ?<Favourite favourites={favourites} removeFavourite={removeFavourite} />: ''}
      <button onClick={(e) => setShow(!show)}>Grocery List ({ingridients.length})</button>
      { show ?<Grocery ingridients={ingridients} removeIngridient={removeIngridient} />: ''}
      <span>Welcome, {name}</span>
    </div>
  )
}
